#pragma once
#include "domain.h"

int validator(Produs produs);
