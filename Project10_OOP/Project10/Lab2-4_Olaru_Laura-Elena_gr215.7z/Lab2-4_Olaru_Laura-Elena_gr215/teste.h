#pragma once

void testProdus();

void testRepository();

void testService();

void testAll();